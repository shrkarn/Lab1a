package com.demo.project.moviesapp.presenter;

/**
 * Created by ramya on 25/3/17.
 */

public interface MoviesListPresenter {
    void getMoviesList(String search_query,int page);

}
