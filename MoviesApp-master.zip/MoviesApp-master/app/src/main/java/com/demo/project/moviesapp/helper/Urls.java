package com.demo.project.moviesapp.helper;

/**
 * Created by ramya on 25/3/17.
 */

public class Urls {
    public static final String BASE_URL="http://www.omdbapi.com";
}
