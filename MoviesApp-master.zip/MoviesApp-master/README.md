# MoviesApp
This app helps to search movies from Open Movie Database
