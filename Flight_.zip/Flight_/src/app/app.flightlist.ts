import { Component, OnInit } from '@angular/core';
import { IFlight } from './flight';
import { FlightService } from './flight.service';

@Component({
    selector: '<my-component></my-component>',
    templateUrl: './app.flightcomponent.html',
    providers: [FlightService]
})

export class FlightList implements OnInit {
    flights: IFlight[];
    
    path: string[] = ['Flight'];
    order: number = 1;

    search: string = '';
    index: number = 0;

    changeIndexToOne(): void {
        this.index = 1;
        console.log("index changed to: " + this.index);
    }
    changeIndexToTwo(): void {
        this.index = 2;
        console.log("index changed to: " + this.index);
    }
    changeIndexToThree(): void {
        this.index = 3;
        console.log("index changed to: " + this.index);
    }
    changeIndexToFour(): void {
        this.index = 4;
        console.log("index changed to: " + this.index);
    }
    changeIndexToFive(): void {
        this.index = 5;
        console.log("index changed to: " + this.index);
    }
    /*id: string = "Id";
    title: string = "Title";
    author: string = "Author";
    year: string = "Year of Publish";*/
    constructor(private flightService: FlightService) {
        
    }
    
    ngOnInit(): void {
        console.log("ng-init called...");
        this.flightService.getAllFlight().subscribe((flightData) => this.flights = flightData);
    }
    sortTable( prop: string ) {
        this.path = prop.split( '.' )
        this.order = this.order * 1 ; // change order
        return false; // do not reload
    }
    deleteData(index:number):void{  
         
        this.flights.splice(index,1);  
        }
}