export interface IFlight {
    id: number;
    name: string;
    arrivalTime: string;
    departureTime: string;
    bookingCost: string;
}