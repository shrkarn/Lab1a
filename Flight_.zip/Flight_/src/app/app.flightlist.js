"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var flight_service_1 = require("./flight.service");
var FlightList = (function () {
    /*id: string = "Id";
    title: string = "Title";
    author: string = "Author";
    year: string = "Year of Publish";*/
    function FlightList(flightService) {
        this.flightService = flightService;
        this.path = ['Flight'];
        this.order = 1;
        this.search = '';
        this.index = 0;
    }
    FlightList.prototype.changeIndexToOne = function () {
        this.index = 1;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToTwo = function () {
        this.index = 2;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToThree = function () {
        this.index = 3;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToFour = function () {
        this.index = 4;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToFive = function () {
        this.index = 5;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.ngOnInit = function () {
        var _this = this;
        console.log("ng-init called...");
        this.flightService.getAllFlight().subscribe(function (flightData) { return _this.flights = flightData; });
    };
    FlightList.prototype.sortTable = function (prop) {
        this.path = prop.split('.');
        this.order = this.order * 1; // change order
        return false; // do not reload
    };
    FlightList.prototype.deleteData = function (index) {
        this.flights.splice(index, 1);
    };
    return FlightList;
}());
FlightList = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.flightcomponent.html',
        providers: [flight_service_1.FlightService]
    }),
    __metadata("design:paramtypes", [flight_service_1.FlightService])
], FlightList);
exports.FlightList = FlightList;
