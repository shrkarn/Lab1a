package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.bean.Movies;
import com.cg.staticdb.MovieDB;
@Repository
public class MovieDaoImpl implements IMovieDao {

	@Override
	public List<Movies> getAllMovies()  {
		// TODO Auto-generated method stub
		return MovieDB.getMovieList();
	}

	@Override
	public void deleteMovie(int id) {
		// TODO Auto-generated method stub
		List<Movies> myList=MovieDB.getMovieList();
		for (Movies mov : myList) {
			if(mov.getMoviesId()==id) {
				myList.remove(mov);
				break;
			}
		}
		
		
	}

	@Override
	public void addMovie(Movies mov) {
		// TODO Auto-generated method stub
		List<Movies> allList=MovieDB.getMovieList();
		allList.add(mov);
		System.out.println(allList);
	}

	@Override
	public List<Movies> searchMovie(String id) {
		// TODO Auto-generated method stub
		Movies mov=new Movies();
		List<Movies> allList=MovieDB.getMovieList();
		List<Movies> searchList = new ArrayList<Movies>();
		for (Movies movie : allList) {
			if(movie.getMoviesGenre().equals(id)) {
				searchList.add(movie);
			}
		}
		return searchList;
	}

	@Override
	public void updateMovie(Movies mov) {
		// TODO Auto-generated method stub
		List<Movies> allList=MovieDB.getMovieList();
		for (Movies movie : allList) {
			if(movie.getMoviesId()==mov.getMoviesId()) {
				movie.setMoviesName(mov.getMoviesName());
				movie.setMoviesRating(mov.getMoviesRating());
				movie.setMoviesGenre(mov.getMoviesGenre());
				break;
			}
		}
	}


}
