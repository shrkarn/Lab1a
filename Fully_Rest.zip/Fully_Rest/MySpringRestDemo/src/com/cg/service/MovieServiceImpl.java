package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Movies;
import com.cg.dao.IMovieDao;

@Service
public class MovieServiceImpl implements IMovieService {

	@Autowired
	IMovieDao movieDao;
	@Override
	public List<Movies> getAllMovies() {
		// TODO Auto-generated method stub
		return movieDao.getAllMovies();
	}
	@Override
	public void deleteMovie(int id) {
		// TODO Auto-generated method stub
		movieDao.deleteMovie(id);
	}
	@Override
	public void addMovie(Movies mov) {
		// TODO Auto-generated method stub
		movieDao.addMovie(mov);
		
	}
	@Override
	public List<Movies> searchMovie(String id) {
		// TODO Auto-generated method stub
		return movieDao.searchMovie(id);
	}
	@Override
	public void updateMovie(Movies mov) {
		// TODO Auto-generated method stub
		movieDao.updateMovie(mov);
	}

	/*@Override
	public void addCountry(Employee country) {
		// TODO Auto-generated method stub
		countryDao.addCountry(country);
	}

	@Override
	public Employee deleteCountry(int id) {
		// TODO Auto-generated method stub
		return countryDao.deleteCountry(id);
	}
*/

}
