import {Component,OnInit} from '@angular/core';
import {Employee} from './employee';
import {Movies} from './movie';
import {MovieService} from './employee.service';
import {ActivatedRoute} from "@angular/router";

@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.employeecomponent.html',
    providers:[MovieService]
})
export class EmployeeList implements  OnInit{
    
    movies:Movies[];
    statusmessage:string;


constructor(private empservice:MovieService,private route: ActivatedRoute) {
   // this.route.params.subscribe( params => this.display();
   
}
ngOnInit(): void {
    //this.display(1);
    this.empservice.getAllMovies().subscribe((data)=>this.movies=data,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
 
}
display(movie:any):void{
    this.movies=movie;
    console.log(movie);
}
delete(id:number):void{
    this.empservice.deleteMovieId(id).subscribe((data)=>this.movies=data,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
}
 
}