package com.cg.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Player;
import com.cg.service.IPlayerService;

@RestController
@RequestMapping(value = "/")
public class PlayerController {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Autowired
	IPlayerService playerService;
	
	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public Player addNewPlayer(@RequestBody Player player) {
		logger.info("Player Added.");
		return playerService.addNewPlayer(player);
	}
	
	@RequestMapping(value = "/delete/{playerId}", method = RequestMethod.DELETE)
	public Player deletePlayer(@PathVariable String playerId) {
		logger.info("Deleting Player: " + playerId);
		return playerService.deletePlayer(playerId);
	}
	
	@RequestMapping(value = "/get/{playerId}", method = RequestMethod.GET)
	public Player getPlayerByID(@PathVariable String playerId) {
		logger.info("Fething Player with Player ID: " + playerId);
		return playerService.getPlayerById(playerId);
	}
	@RequestMapping(value = "/all", method = RequestMethod.GET)
	public List<Player> getAllPlayers() {
		logger.info("Getting All Players...");
		System.out.println("Players are displayed...");
		return playerService.getAllPlayers();
	}
}
