export interface IPlayer {
    playerId: string;
    name: string;
    age: number;
    mobileNo: string;
    game: string;
}