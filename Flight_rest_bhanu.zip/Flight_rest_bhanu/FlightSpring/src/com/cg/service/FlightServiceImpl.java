package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.cg.beans.Flight;
import com.cg.dao.IFlightDao;
@Service("fservice")
public class FlightServiceImpl implements IFlightService {
    @Autowired
	private IFlightDao fdao;
	@Override
	public List<Flight> getAllFlight() {
		
		
		
		return fdao.getAllFlight();
	}
	@Override
	public void deleteFlight(int id) {
        fdao.deleteFlight(id);
	}
	@Override
	public void addFlight(Flight flight) {
		fdao.addFlight(flight);
	}
	@Override
	public Flight searchFlight(int id) {
		return fdao.searchFlight(id);
	}
	@Override
	public void updateFlight(Flight flight) {
        fdao.updateFlight(flight);		
	}

}
