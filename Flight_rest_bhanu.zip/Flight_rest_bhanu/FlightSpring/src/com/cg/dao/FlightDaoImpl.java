package com.cg.dao;

import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;

import com.cg.beans.Flight;
import com.cg.staticDB.FlightDb;

@Repository("fdao")
public class FlightDaoImpl implements IFlightDao {
	
	

	@Override
	public List<Flight> getAllFlight() {
		return FlightDb.getFlightList();
	}

	@Override
	public void deleteFlight(int id) {
		    List<Flight> fList=FlightDb.getFlightList();
		    for(Flight flight:fList){
		    	if(flight.getId()==id){
		    		fList.remove(flight);break;
		    	}
		    }
	}

	@Override
	public void addFlight(Flight flight) {
      		List<Flight> fList=FlightDb.getFlightList();
      		fList.add(flight);
	}

	@Override
	public Flight searchFlight(int id) {
		Flight flight1=new Flight();
		List<Flight> fList=FlightDb.getFlightList();
		for(Flight flight:fList){
			if(flight.getId()==id){
				flight1=flight;break;
			}
		}
		return flight1;
	}

	@Override
	public void updateFlight(Flight flight) {
		List<Flight> fList=FlightDb.getFlightList();
		for(Flight flight1:fList){
			if(flight1.getId()==flight.getId()){
				flight1.setFname(flight.getFname());
				flight1.setDepartureTime(flight.getDepartureTime());
				flight1.setArrivalTime(flight.getArrivalTime());
				flight1.setStatus(flight.getStatus());
				flight1.setCost(flight.getCost());
				break;
			}
		}
	}

}
