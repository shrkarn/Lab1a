package com.cg.dao;

import java.util.List;

import org.springframework.ui.Model;

import com.cg.beans.Flight;

public interface IFlightDao {

	List<Flight> getAllFlight();

	void deleteFlight(int id);

	void addFlight(Flight flight);

	Flight searchFlight(int id);

	void updateFlight(Flight flight);

}
