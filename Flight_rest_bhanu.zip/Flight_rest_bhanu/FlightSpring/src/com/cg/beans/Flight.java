package com.cg.beans;

public class Flight {
	private int id;
	private String fname;
	private String departureTime;
	private String arrivalTime;
	private String status;
	private double cost;

	public Flight() {

	}

	

	public Flight(int id, String fname, String departureTime,
			String arrivalTime, String status, double cost) {
		super();
		this.id = id;
		this.fname = fname;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.status = status;
		this.cost= cost;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(String departureTime) {
		this.departureTime = departureTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}
	
	
	@Override
	public String toString() {
		return "Flight [id=" + id + ", fname=" + fname + ", departureTime="
				+ departureTime + ", arrivalTime=" + arrivalTime + ", status="
				+ status + ", cost=" + cost + "]";
	}
}
