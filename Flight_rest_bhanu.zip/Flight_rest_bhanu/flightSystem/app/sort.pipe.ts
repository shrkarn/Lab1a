
import { Pipe, PipeTransform } from '@angular/core';
import { IFlight } from "./flight";

@Pipe({
  name: 'sortingCompanies',
  pure:false
})
export class SortingCompaniesPipe implements PipeTransform {

  transform(flight: IFlight[], path: string[], order: number): IFlight[] {

    // Check if is not null
    if (!flight || !path || !order) return flight;

    return flight.sort((a: IFlight, b: IFlight) => {
      // We go for each property followed by path
      path.forEach(property => {
        a = a[property];
        b = b[property];
      })

      // Order * (-1): We change our order
      return a > b ? order : order * (- 1);
    })
  }

}