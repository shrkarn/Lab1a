import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';
import { FlightList  }  from './app.flightlist';
import {HttpModule} from '@angular/http';
import { SearchPipe }  from './filter';
import { SortingCompaniesPipe }  from './sort.pipe';

@NgModule({
  imports:      [ BrowserModule, FormsModule, HttpModule],
  declarations: [ AppComponent, FlightList, SearchPipe,SortingCompaniesPipe],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
